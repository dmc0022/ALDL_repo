HUB75 GIF HEX File README

This folder contains HEX files used to load GIF frame data into the HUB75 LED matrix display project.

File Naming Format:
gif<ID>_<FRAMES>.hex

Example:
gif54_79.hex

Meaning:
- gif54: The GIF identifier. This is used to distinguish one converted GIF/image sequence from another.
- 79: The number of frames in the HEX file.

When using one of these HEX files in the HUB75 display code, update the frame count value in the code to match the second number in the filename.

For example, if the selected file is:

gif54_79.hex

then the HUB75 display code should be configured for 79 frames.

General Setup Steps:
1. Place the desired .hex file in the project memory/init file location.
2. Update the memory initialization filename in the HUB75 display code if needed.
3. Update the frame count parameter/value to match the number after the underscore.
4. Recompile/reload the FPGA design.

Note:
The first number only identifies the GIF. The second number is the important value for setting how many frames the display code should cycle through.
